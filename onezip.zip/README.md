# Mwaniki Gatimu Online Portfolio

This version adds a real online profile using Supabase.

Files:
- index.html = public portfolio
- admin.html = private login/edit page
- schema.sql = database + security rules

Setup:
1. Create a Supabase project.
2. In Supabase SQL Editor, run schema.sql.
3. Create your own email/password account in Supabase Auth.
4. Copy your Project URL and Publishable Key.
5. Replace the two PASTE_... placeholders in BOTH HTML files.
6. Upload the files to GitHub Pages.
7. Open admin.html, log in, and save your profile.

Security:
Use only the Supabase Publishable Key in browser code. Never put a service-role or secret key in frontend files.
